package com.pkbhai.flutterdesign

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
